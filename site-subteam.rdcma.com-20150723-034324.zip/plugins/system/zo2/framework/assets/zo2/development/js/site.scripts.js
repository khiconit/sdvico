(function (w, z, $) {
    var _site = {
    };
    /** Init zo2.site **/
    z.site = _site;
})(window, zo2, zo2.jQuery);