<div id="myTabZo2SidebarContent" class="tab-content">
    <?php $this->load('admin/body/sidebar/content_general.php'); ?>
    <?php $this->load('admin/body/sidebar/content_fonts.php'); ?>
    <?php $this->load('admin/body/sidebar/content_layout.php'); ?>
    <?php $this->load('admin/body/sidebar/content_themecolor.php'); ?>
    <?php $this->load('admin/body/sidebar/content_menu.php'); ?>    
    <?php $this->load('admin/body/sidebar/content_advanced.php'); ?>
    <?php $this->load('admin/body/sidebar/content_about.php'); ?>
</div>